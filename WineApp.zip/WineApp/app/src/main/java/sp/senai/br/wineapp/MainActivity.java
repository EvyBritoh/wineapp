package sp.senai.br.wineapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView lvVinhos;
    List<BaseArrayList> arrayLista;
    String sIP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        sIP = getString(R.string.ip);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        lvVinhos = findViewById(R.id.lvVinhos);
        if (arrayLista==null){
            arrayLista = new ArrayList<>();
        }
        preencheLista();
    }
    public void novo(View n){
        Intent cad = new Intent(MainActivity.this, Cadastrar.class);
        startActivity(cad);
        finish();
    }
    public void preencheLista() {
        try {
            arrayLista.clear();
            URL site = new URL("http://"+sIP+
                    ":8080/Wine/buscarDados.php");
            HttpURLConnection conn =
                    (HttpURLConnection) site.openConnection();
            conn.connect();
            //É usado para obter um fluxo de dados vindo de uma fonte exterma
            InputStream entradaDados = conn.getInputStream();
            BufferedReader leitor = (new BufferedReader(new InputStreamReader(entradaDados)));
            String sLinha;
            StringBuilder decodificador = new StringBuilder();
            while ((sLinha = leitor.readLine())!=null){
                decodificador.append(sLinha);
            }
            String stringJSON = decodificador.toString();
            JSONArray saidaJSON = new JSONArray(stringJSON);
            BaseArrayList cabecalho = new BaseArrayList();
            cabecalho.id = "ID";
            cabecalho.nome = "NOME";
            cabecalho.nota = "NOTA";
            arrayLista.add(cabecalho);
            for (int i=0;i<saidaJSON.length();i++){
                JSONObject linhaJSON = saidaJSON.getJSONObject(i);
                BaseArrayList reg = new BaseArrayList();
                reg.id = linhaJSON.getString("id");
                reg.nome = linhaJSON.getString("nome");
                reg.nota = linhaJSON.getString("nota");
                arrayLista.add(reg);
            }
            ListaAdapter adpt = new ListaAdapter(getBaseContext(), R.layout.layout_lista,arrayLista);
            lvVinhos.setAdapter(adpt);
        }catch (MalformedURLException m){
            m.printStackTrace();
        }catch (IOException i){
            i.printStackTrace();
        }catch (JSONException j){
            j.printStackTrace();
        }
    }
    }