package sp.senai.br.wineapp;

import androidx.annotation.NonNull;

public class BaseArrayList {
    public String id,nome,tipo,origem,nota;


}
