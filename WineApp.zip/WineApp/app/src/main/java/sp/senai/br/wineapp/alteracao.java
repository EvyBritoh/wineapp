package sp.senai.br.wineapp;

public class alteracao {
}
