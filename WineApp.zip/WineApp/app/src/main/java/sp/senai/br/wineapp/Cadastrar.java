package sp.senai.br.wineapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.EditText;
import android.widget.RatingBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class Cadastrar extends AppCompatActivity {
    String sIP;
    EditText etNome, etOrigem, etTipo;
    RatingBar rbNota;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cadastrar);
        sIP = getString(R.string.ip);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etNome = findViewById(R.id.etNome);
        etOrigem = findViewById(R.id.etOrigem);
        etTipo = findViewById(R.id.etTIpo);
        rbNota = findViewById(R.id.rbNota);
    }

    public void salvar(View s){
        try {
            URL site = new URL("http://"+sIP+
                    ":8080/Wine/inserirDados.php?nome="+
                    etNome.getText().toString() +"&tipo="+
                    etTipo.getText().toString()+"&origem="+
                    etOrigem.getText().toString()+"&nota="+
                    rbNota.getRating());
            HttpURLConnection conn =
                    (HttpURLConnection) site.openConnection();
            conn.connect();
            //É usado para obter um fluxo de dados vindo de uma fonte exterma
            InputStream entradaDados = conn.getInputStream();
            Intent it = new Intent(Cadastrar.this, MainActivity.class);
            startActivity(it);
            finish();
        }catch (MalformedURLException e){
          e.printStackTrace();
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    public void voltarView(View data){
        Intent it = new Intent(Cadastrar.this, MainActivity.class);
        startActivity(it);
        finish();
    }
}