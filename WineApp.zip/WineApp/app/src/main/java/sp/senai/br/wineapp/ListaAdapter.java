package sp.senai.br.wineapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class ListaAdapter extends ArrayAdapter<BaseArrayList> {
    private List<BaseArrayList> itens;

    public ListaAdapter(Context context, int textViewResourceId,
                        List<BaseArrayList> items) {
        super(context, textViewResourceId, items);
        this.itens = items;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v = convertView;
        if (v==null){
            Context ctx = getContext();
            LayoutInflater vi = (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = vi.inflate(R.layout.layout_lista, null);
        }
        BaseArrayList base = itens.get(position);
        if (base !=null){
            ((TextView) v.findViewById(R.id.tvId)).setText(base.id);
            ((TextView) v.findViewById(R.id.tvNome)).setText(base.nome);
            ((TextView) v.findViewById(R.id.tvNota)).setText(base.nota);
        }
        return v;
    }
}
